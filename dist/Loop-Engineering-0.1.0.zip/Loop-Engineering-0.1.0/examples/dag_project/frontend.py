def payload():
    return {}
